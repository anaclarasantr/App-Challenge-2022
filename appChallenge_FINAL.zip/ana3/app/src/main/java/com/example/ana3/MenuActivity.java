package com.example.ana3;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MenuActivity extends AppCompatActivity {
    Button btnProvedores;
    Button btnPlanos;
    Button btnInstaladores;

    String user_id;

    private AppBarConfiguration mAppBarConfiguration;

    //Funcionalidade de Layout
    @Override
    protected void onCreate(Bundle savedInstancesState){
        super.onCreate(savedInstancesState);
        setContentView(R.layout.activity_menu);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Salva o valor do id carregado da intent enviada
        Intent i = getIntent();
        user_id = i.getStringExtra("id");

        //Botões de direcionamento de telas
        btnPlanos = (Button) findViewById(R.id.btnPlanos);
        btnPlanos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MenuActivity.this, PlanosActivity.class);
                startActivity(intent);
            }
        });

        btnProvedores = (Button) findViewById(R.id.btnProvedores);
        btnProvedores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Permissao para localizacao
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(MenuActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MenuActivity.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);

                }else{
                    Intent intent = new Intent(MenuActivity.this, MapsActivity.class);
                    startActivity(intent);
                }
            }
        });
        btnInstaladores = (Button) findViewById(R.id.btnInstaladores);
        btnInstaladores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MenuActivity.this, InstaladoresActivity.class);
                startActivity(intent);
            }
        });
    }

    //suporte de navegação de telas
    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

}
