package com.example.ana3;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {


    private GoogleMap mMap;

    Double lat = -22.24685027032397 ;
    Double log = -45.708404672329856;
    Double lat1 = -23.59858039475002;
    Double log1 = -46.690389680459;
    Double lat2 = -22.252509270483266;
    Double log2 = -45.70141451650552;
    Double lat3 = -22.25111832787015;
    Double log3 = -45.704983216505546;
    Double lat4 = -22.411268815434266;
    Double log4 = -45.79646257417219;
    Double lat5 = -22.231912635456716;
    Double log5 = -45.941614187670964;
    //MqttHelper mqttHelper;
    //float zoomLevel = 16.0f; //Ate 21
    //int contador = 0;
    //double lat = 0;
    //double lon = 0;
    //LatLng localizacao_antiga = new LatLng(lat, lon);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        //MQTT----------------------------------------------------------------------------------------
        /*
        mqttHelper = new MqttHelper(getApplicationContext());
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                //Aparece essa mensagem sempre que for conectado com o broker
                Toast.makeText(getApplicationContext(), "Conectado", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void connectionLost(Throwable throwable) {
                //Aparece essa mensagem sempre que a conexão for perdida
                Toast.makeText(getApplicationContext(), "Conexão perdida", Toast.LENGTH_SHORT).show();
            }

            @Override
            // messageArrived é uma função que é chamada toda vez que o cliente MQTT recebe uma mensagem
            public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                Log.w("Debug", mqttMessage.toString());
                Toast.makeText(getApplicationContext(), mqttMessage.toString(), Toast.LENGTH_SHORT).show();
                if (topic.equals("SmartBike/Lat")) {
                    lat = Double.parseDouble(mqttMessage.toString());
                }
                if (topic.equals("SmartBike/Lon")) {
                    lon = Double.parseDouble(mqttMessage.toString());

                    if(lat != 0 && lon !=0) {
                        if(contador!=0){
                            LatLng localizacao = new LatLng(lat, lon);
                            mMap.addMarker(new MarkerOptions().position(localizacao).title(String.valueOf(contador)));
                            mMap.addPolyline(new PolylineOptions().clickable(true).add(localizacao,localizacao_antiga));
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(localizacao, zoomLevel));
                        }

                        localizacao_antiga = new LatLng(lat, lon);
                        contador++;
                    }
                    lat = 0;
                    lon = 0;

                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

            }
        });
         */
        //MQTT----------------------------------------------------------------------------------------

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        assert mapFragment != null;

        mapFragment.getMapAsync(this);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Vivavox
        LatLng rota = new LatLng(lat, log);
        mMap.addMarker(new MarkerOptions().position(rota).title("Vivavox"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(rota));

        //Viasat
        LatLng rota1 = new LatLng(lat1, log1);
        mMap.addMarker(new MarkerOptions().position(rota1).title("ViaSat"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(rota));

        //Sapucai net
        LatLng rota2 = new LatLng(lat2, log2);
        mMap.addMarker(new MarkerOptions().position(rota2).title("Sapucaí Net"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(rota));

        //VOUE
        LatLng rota3 = new LatLng(lat3, log3);
        mMap.addMarker(new MarkerOptions().position(rota3).title("Voue"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(rota));

        //SBS net
        LatLng rota4 = new LatLng(lat4, log4);
        mMap.addMarker(new MarkerOptions().position(rota4).title("SBS Net"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(rota));

        //Turbonet
        LatLng rota5 = new LatLng(lat5, log5);
        mMap.addMarker(new MarkerOptions().position(rota5).title("Turbonet"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(rota));

        final LatLng minhaLoc = new LatLng(-22.42258896985633, -45.794001590341516);
        Marker loc = mMap.addMarker(
                new MarkerOptions().position(minhaLoc).title("Minha localização")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
    }
}